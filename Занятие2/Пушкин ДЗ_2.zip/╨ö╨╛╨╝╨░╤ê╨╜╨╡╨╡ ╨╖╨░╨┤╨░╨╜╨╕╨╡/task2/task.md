Для задачи поиска значения минимального элемента есть более изящный способ.
Решите её с помощью встроенной функции.

<div class="hint">
    <a href="https://docs.python.org/3/library/functions.html#min">
        Встроенная функция min
    </a>
</div>
